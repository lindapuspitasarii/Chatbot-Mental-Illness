from flask import Flask, render_template, jsonify, request
import process


app = Flask(__name__)

app.config['SECRET_KEY'] = 'enter-a-very-secretive-key-3479373'


@app.route('/', methods=["GET", "POST"])
def index():
    return render_template('index.html')

@app.route("/livechat")
def livechat():
    return render_template("livechat.html")
# @app.route('/', methods=["GET", "POST"])
# def index():
#     return render_template('index.html', **locals())

# @app.route("/livechat")
# def livechat():
#     return render_template("livechat.html", **locals())

@app.route('/chatbot', methods=["GET", "POST"])
@app.route("/get")
def get_bot_response():
    user_input = str(request.args.get('msg'))
    result = process.chatbot_response(user_input)
    return result


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)